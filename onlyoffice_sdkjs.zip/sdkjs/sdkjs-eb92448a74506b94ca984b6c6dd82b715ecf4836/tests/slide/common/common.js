/*
 * (c) Copyright Ascensio System SIA 2010-2022
 *
 * This program is a free software product. You can redistribute it and/or
 * modify it under the terms of the GNU Affero General Public License (AGPL)
 * version 3 as published by the Free Software Foundation. In accordance with
 * Section 7(a) of the GNU AGPL its Section 15 shall be amended to the effect
 * that Ascensio System SIA expressly excludes the warranty of non-infringement
 * of any third-party rights.
 *
 * This program is distributed WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR  PURPOSE. For
 * details, see the GNU AGPL at: http://www.gnu.org/licenses/agpl-3.0.html
 *
 * You can contact Ascensio System SIA at 20A-12 Ernesta Birznieka-Upisha
 * street, Riga, Latvia, EU, LV-1050.
 *
 * The  interactive user interfaces in modified source and object code versions
 * of the Program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU AGPL version 3.
 *
 * Pursuant to Section 7(b) of the License you must retain the original Product
 * logo when distributing the program. Pursuant to Section 7(e) we decline to
 * grant you any rights under trademark law for use of our trademarks.
 *
 * All the Product's GUI elements, including illustrations and icon sets, as
 * well as technical writing content are licensed under the terms of the
 * Creative Commons Attribution-ShareAlike 4.0 International. See the License
 * terms at http://creativecommons.org/licenses/by-sa/4.0/legalcode
 *
 */

"use strict";

const AscTest = window.AscTest || {};

(function(window)
{
  const Letter = {
    f : 102,
    i : 105,

    x : 120,
    y : 121,
    z : 122
  };

  AscCommon.g_oTableId = {
    map : {},
    Add : function(c, id)
    {
      this.map[id] = c;
    },
    Get_ById : function(id)
    {
      if (!this.map[id])
        return null;

      return this.map[id];
    },
    TurnOff : function(){},
    TurnOn : function(){},
    init : function () {},
  };

  AscCommon.g_oIdCounter.m_bLoad = false;
  AscCommon.g_oIdCounter.m_bRead = false;


  AscTest.createShape = function (oParent) {
    AscCommon.History.Create_NewPoint();
    const nOldSpTreeLength = oParent.cSld.spTree.length
    var oShapeTrack = new AscFormat.NewShapeTrack('rect', 0, 0, AscFormat.GetDefaultTheme(), null, null, null, 0);
    oShapeTrack.track({}, 100, 100);
    var oShape = oShapeTrack.getShape(false, AscTest.DrawingDocument, null);
    oShape.setBDeleted(false);
    oShape.setParent(oParent);
    //oShape.createTextBody();
    oShape.addToDrawingObjects();
    if (oParent.cSld.spTree.length !== nOldSpTreeLength + 1) {
      throw new Error("Shape didn't added");
    }
    return oShape;
  };


  AscTest.Letter = Letter;

})(window);
